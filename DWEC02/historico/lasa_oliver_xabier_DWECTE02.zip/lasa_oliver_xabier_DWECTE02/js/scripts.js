'use strict'

// Importo la clase desde su carpeta del directorio MCV
// import Socios from './objects.js'
console.log('Empieza el programa')

// ------------------- VARIABLES GLOBALES ------------------------

// capturamos el formulario de introduccion de socios - Ejercicio 1
const formulario = document.querySelector('#formNombre')

// capturamos el contenedor donde escribiremos los socios - Ejercicio 2
const contenedorEscribirSocios = document.getElementById(
  'contenedorPintarSocios'
)

// TODO: array para añadir los socios
var arraySocios = []

cargarSociosJSON()
// ------------------- FUNCIONES ------------------------

// EJERCICIO 1

/*
  funcion para leer del JSON
*/
function cargarSociosJSON () {
  let path = '../model/datosSocios.json'

  let request = new Request(path, {
    headers: new Headers({
      'Content-Type': 'text/json'
    }),
    method: 'GET'
  })

  fetch(request).then(response => {
    response.json().then(data => {
      console.log('Datos', data)
    })
  })
}

/* 
TODO:  metodo para añadir socios al array 
    cuando arranca la pagina web
*/
function aniadirSociosInicialesArray () {
  //  TODO: cargar el fichero JSON, parsearlo a objetos tipo "socio" y añadirlos al array
  fs.readFileSync('../model/datosSocios.json')
  var fichero = JSON.parse(data)
  //Con un bucle FOR recorro el JSON parseado para crear nuevos objetos
  // 
  fichero.forEach(socioJson => {
    let socio = new Socio(socioJson.id, socioJson.nombre, socioJson.apellido)
    arraySocios.push(socio)
  }) 
    // //Creo un nuevo objeto de la clase Socios
    // let socio = new Socio(fichero[i].id, fichero[i].nombre, fichero[i].apellido)
    // //Añado el objeto a la última posición disponible del array
    // arraySocios.push(socio)
  }


/*
    TODO: Meotodo para capturar los datos del socio introducidor en el formulario

*/
function capturarDatosSocio () {
  // TODO: recoger los el nombre y apellido del HTML
  let nombre = document.getElementById("fnombre")
  let apellido = document.getElementById("fapellido")
  // TODO: crear el socio y añadirlo al array 
  let idSocio = crearID()
  crearSocio(idSocio, nombre, apellido)
}

/* 
TODO: 
    Metodo para crear un socio pasandole el nombre y el apellido
    y añadirlo al array
 */
function crearSocio (idSocio, nombre, apellido) {
  // TODO: crear objeto socio
  let socioNuevo = new Socio(idSocio, nombre, apellido)
  // TODO: añadir el objeto al array
  arraySocios.push(socioNuevo)
}

/*
TODO: 
    Metodo para crear el ID del socio en funcion del ultimo
    ID que hay en el array de socios
*/
function crearID () {
  // TODO: mirar el id del ultimo socio del array y sumarle uno
  
  let ultimoId = arraySocios.length
  let idUltimo = arraySocios[arraySocios.length]
  // Condición para comprobar si el índice del array es correlativo con el número de socio 
  if (ultimoId != idUltimo){
    console.log('Algo va mal, los índices no coinciden')
    return ultimoId + 1
  } else{
    return idUltimo + 1
  }
    
}

// EJERCICIO 2

/*
  TODO: metodo que elimina la lista previamente pintada en el contenedor asignado 
  para pintar socios, recorre el array con un bucle y pinta los socios 
*/
function pintarListaSocios () {
  //borramos todo lo que hay en el div 
  document.getElementById('contenedorPintarSocios').innerHTML = ''
  for (let i=0;i<arraySocios.length;i++) {
    //creamos una etiqueta <li> por cada socio y a continuación escribimos los datos del socio
    let li = document.createElement('li')
    let id = arraySocios[i].id 
    let nombre = arraySocios[i].nombre 
    let apellido = arraySocios[i].apellido
    li.textContent = 'Socio número ' + id + ': ' + nombre + ' ' + apellido
    //agregamos el elemento li al contenedor
    document.getElementById('contenedorPintarSocios').appendChild(li)
    }
  //TODO: debemos añadir los socios a la pagina web

}

// ------------------- MAIN ------------------------

// TODO: añadimos los socios iniciales cuando empieza el programa
var fnombre = document.getElementById('fnombre')
var fapellido = document.getElementById('fapellido')
var btnguardar = document.getElementById('butAniadirSocio')

btnguardar.addEventListener("click", guardar(fnombre, fapellido))

function guardar(fnombre, fapellido){
  var id = crearID()
  //Estructura condicional para asegurarnos de que se rellenan ambos campos
  if (!nombre || !apellido){
    alert ("Hay campos vacios")
    }else{
      crearSocio(id, fnombre, fapellido)
      fnombre.value=''
      fapellido.value=''
      pintarListaSocios()
    }
}

crearSocio ()
pintarListaSocios()

console.log('Acaba el programa')